﻿namespace spider
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtProfile = new System.Windows.Forms.TextBox();
            this.btnTakeOff = new System.Windows.Forms.Button();
            this.btnLand = new System.Windows.Forms.Button();
            this.btnInit = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolSSLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolSSCommand = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolSPBattery = new System.Windows.Forms.ToolStripProgressBar();
            this.btnEStop = new System.Windows.Forms.Button();
            this.btnYawUp = new System.Windows.Forms.Button();
            this.btnYawDown = new System.Windows.Forms.Button();
            this.btnPitchUp = new System.Windows.Forms.Button();
            this.btnPitchDown = new System.Windows.Forms.Button();
            this.btnRollDown = new System.Windows.Forms.Button();
            this.btnRollUp = new System.Windows.Forms.Button();
            this.btnGazDown = new System.Windows.Forms.Button();
            this.btnGazUp = new System.Windows.Forms.Button();
            this.btnTest1 = new System.Windows.Forms.Button();
            this.btnPatternRoute = new System.Windows.Forms.Button();
            this.btnPattern = new System.Windows.Forms.Button();
            this.devListBox = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.trkBrHeight = new System.Windows.Forms.TrackBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnM2Land = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.trkBrGazAcc = new System.Windows.Forms.TrackBar();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkBrHeight)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkBrGazAcc)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(301, 10);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(115, 27);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.Search_Click);
            // 
            // txtProfile
            // 
            this.txtProfile.Location = new System.Drawing.Point(6, 32);
            this.txtProfile.Multiline = true;
            this.txtProfile.Name = "txtProfile";
            this.txtProfile.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtProfile.Size = new System.Drawing.Size(290, 316);
            this.txtProfile.TabIndex = 4;
            this.txtProfile.Text = "No device selected.";
            this.txtProfile.Click += new System.EventHandler(this.txtProfile_Click);
            this.txtProfile.DoubleClick += new System.EventHandler(this.txtProfile_DoubleClick);
            // 
            // btnTakeOff
            // 
            this.btnTakeOff.Location = new System.Drawing.Point(301, 78);
            this.btnTakeOff.Name = "btnTakeOff";
            this.btnTakeOff.Size = new System.Drawing.Size(115, 27);
            this.btnTakeOff.TabIndex = 5;
            this.btnTakeOff.Text = "TakeOff";
            this.btnTakeOff.UseVisualStyleBackColor = true;
            this.btnTakeOff.Click += new System.EventHandler(this.btnTakeOff_Click);
            // 
            // btnLand
            // 
            this.btnLand.Location = new System.Drawing.Point(301, 145);
            this.btnLand.Name = "btnLand";
            this.btnLand.Size = new System.Drawing.Size(115, 27);
            this.btnLand.TabIndex = 6;
            this.btnLand.Text = "Land";
            this.btnLand.UseVisualStyleBackColor = true;
            this.btnLand.Click += new System.EventHandler(this.btnLand_Click);
            // 
            // btnInit
            // 
            this.btnInit.Location = new System.Drawing.Point(301, 44);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(115, 27);
            this.btnInit.TabIndex = 7;
            this.btnInit.Text = "Initialize";
            this.btnInit.UseVisualStyleBackColor = true;
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolSSLabel2,
            this.toolSSCommand,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel1,
            this.toolSPBattery});
            this.statusStrip1.Location = new System.Drawing.Point(5, 350);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 9, 0);
            this.statusStrip1.Size = new System.Drawing.Size(490, 114);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolSSLabel2
            // 
            this.toolSSLabel2.Name = "toolSSLabel2";
            this.toolSSLabel2.Size = new System.Drawing.Size(67, 109);
            this.toolSSLabel2.Text = "Command:";
            // 
            // toolSSCommand
            // 
            this.toolSSCommand.AutoSize = false;
            this.toolSSCommand.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolSSCommand.Name = "toolSSCommand";
            this.toolSSCommand.Size = new System.Drawing.Size(300, 109);
            this.toolSSCommand.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(55, 109);
            this.toolStripStatusLabel2.Text = "Battery : ";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 109);
            // 
            // toolSPBattery
            // 
            this.toolSPBattery.AutoSize = false;
            this.toolSPBattery.Name = "toolSPBattery";
            this.toolSPBattery.Size = new System.Drawing.Size(54, 108);
            this.toolSPBattery.Value = 25;
            // 
            // btnEStop
            // 
            this.btnEStop.BackColor = System.Drawing.Color.Salmon;
            this.btnEStop.Location = new System.Drawing.Point(301, 278);
            this.btnEStop.Name = "btnEStop";
            this.btnEStop.Size = new System.Drawing.Size(115, 57);
            this.btnEStop.TabIndex = 9;
            this.btnEStop.Text = "E_STOP";
            this.btnEStop.UseVisualStyleBackColor = false;
            this.btnEStop.Click += new System.EventHandler(this.btnEStop_Click);
            // 
            // btnYawUp
            // 
            this.btnYawUp.Location = new System.Drawing.Point(301, 246);
            this.btnYawUp.Name = "btnYawUp";
            this.btnYawUp.Size = new System.Drawing.Size(51, 27);
            this.btnYawUp.TabIndex = 10;
            this.btnYawUp.Text = "Yaw+";
            this.btnYawUp.UseVisualStyleBackColor = true;
            this.btnYawUp.Click += new System.EventHandler(this.btnYawUp_Click);
            // 
            // btnYawDown
            // 
            this.btnYawDown.Location = new System.Drawing.Point(366, 246);
            this.btnYawDown.Name = "btnYawDown";
            this.btnYawDown.Size = new System.Drawing.Size(51, 27);
            this.btnYawDown.TabIndex = 11;
            this.btnYawDown.Text = "Yaw-";
            this.btnYawDown.UseVisualStyleBackColor = true;
            this.btnYawDown.Click += new System.EventHandler(this.btnYawDown_Click);
            // 
            // btnPitchUp
            // 
            this.btnPitchUp.Location = new System.Drawing.Point(300, 212);
            this.btnPitchUp.Name = "btnPitchUp";
            this.btnPitchUp.Size = new System.Drawing.Size(51, 27);
            this.btnPitchUp.TabIndex = 12;
            this.btnPitchUp.Text = "Pitch+";
            this.btnPitchUp.UseVisualStyleBackColor = true;
            this.btnPitchUp.Click += new System.EventHandler(this.btnPitchUp_Click);
            // 
            // btnPitchDown
            // 
            this.btnPitchDown.Location = new System.Drawing.Point(366, 212);
            this.btnPitchDown.Name = "btnPitchDown";
            this.btnPitchDown.Size = new System.Drawing.Size(51, 27);
            this.btnPitchDown.TabIndex = 13;
            this.btnPitchDown.Text = "Pitch-";
            this.btnPitchDown.UseVisualStyleBackColor = true;
            this.btnPitchDown.Click += new System.EventHandler(this.btnPitchDown_Click);
            // 
            // btnRollDown
            // 
            this.btnRollDown.Location = new System.Drawing.Point(364, 178);
            this.btnRollDown.Name = "btnRollDown";
            this.btnRollDown.Size = new System.Drawing.Size(51, 27);
            this.btnRollDown.TabIndex = 15;
            this.btnRollDown.Text = "Roll-";
            this.btnRollDown.UseVisualStyleBackColor = true;
            this.btnRollDown.Click += new System.EventHandler(this.btnRollDown_Click);
            // 
            // btnRollUp
            // 
            this.btnRollUp.Location = new System.Drawing.Point(300, 178);
            this.btnRollUp.Name = "btnRollUp";
            this.btnRollUp.Size = new System.Drawing.Size(51, 27);
            this.btnRollUp.TabIndex = 14;
            this.btnRollUp.Text = "Roll+";
            this.btnRollUp.UseVisualStyleBackColor = true;
            this.btnRollUp.Click += new System.EventHandler(this.btnRollUp_Click);
            // 
            // btnGazDown
            // 
            this.btnGazDown.Location = new System.Drawing.Point(364, 111);
            this.btnGazDown.Name = "btnGazDown";
            this.btnGazDown.Size = new System.Drawing.Size(51, 27);
            this.btnGazDown.TabIndex = 17;
            this.btnGazDown.Text = "Gaz-";
            this.btnGazDown.UseVisualStyleBackColor = true;
            this.btnGazDown.Click += new System.EventHandler(this.btnGazDown_Click);
            // 
            // btnGazUp
            // 
            this.btnGazUp.Location = new System.Drawing.Point(300, 111);
            this.btnGazUp.Name = "btnGazUp";
            this.btnGazUp.Size = new System.Drawing.Size(51, 27);
            this.btnGazUp.TabIndex = 16;
            this.btnGazUp.Text = "Gaz+";
            this.btnGazUp.UseVisualStyleBackColor = true;
            this.btnGazUp.Click += new System.EventHandler(this.btnGazUp_Click);
            // 
            // btnTest1
            // 
            this.btnTest1.Location = new System.Drawing.Point(6, 202);
            this.btnTest1.Name = "btnTest1";
            this.btnTest1.Size = new System.Drawing.Size(115, 27);
            this.btnTest1.TabIndex = 18;
            this.btnTest1.Text = "Mission2 Start";
            this.btnTest1.UseVisualStyleBackColor = true;
            this.btnTest1.Click += new System.EventHandler(this.btnTest1_Click);
            // 
            // btnPatternRoute
            // 
            this.btnPatternRoute.Location = new System.Drawing.Point(6, 18);
            this.btnPatternRoute.Name = "btnPatternRoute";
            this.btnPatternRoute.Size = new System.Drawing.Size(115, 27);
            this.btnPatternRoute.TabIndex = 19;
            this.btnPatternRoute.Text = "경로설정";
            this.btnPatternRoute.UseVisualStyleBackColor = true;
            this.btnPatternRoute.Click += new System.EventHandler(this.btnPatternRoute_Click);
            // 
            // btnPattern
            // 
            this.btnPattern.Location = new System.Drawing.Point(6, 53);
            this.btnPattern.Name = "btnPattern";
            this.btnPattern.Size = new System.Drawing.Size(115, 27);
            this.btnPattern.TabIndex = 20;
            this.btnPattern.Text = "패턴비행";
            this.btnPattern.UseVisualStyleBackColor = true;
            this.btnPattern.Click += new System.EventHandler(this.btnPattern_Click);
            // 
            // devListBox
            // 
            this.devListBox.FormattingEnabled = true;
            this.devListBox.Location = new System.Drawing.Point(6, 10);
            this.devListBox.Name = "devListBox";
            this.devListBox.Size = new System.Drawing.Size(290, 20);
            this.devListBox.Sorted = true;
            this.devListBox.TabIndex = 60;
            this.devListBox.Text = "?";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblHeight);
            this.groupBox1.Controls.Add(this.trkBrHeight);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(6, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(115, 162);
            this.groupBox1.TabIndex = 61;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "고도 조절";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 12);
            this.label5.TabIndex = 28;
            this.label5.Text = "145cm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 12);
            this.label4.TabIndex = 27;
            this.label4.Text = "60cm";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(3, 70);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(39, 12);
            this.lblHeight.TabIndex = 26;
            this.lblHeight.Text = "85cm";
            // 
            // trkBrHeight
            // 
            this.trkBrHeight.LargeChange = 1;
            this.trkBrHeight.Location = new System.Drawing.Point(37, 13);
            this.trkBrHeight.Maximum = 2;
            this.trkBrHeight.Name = "trkBrHeight";
            this.trkBrHeight.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trkBrHeight.Size = new System.Drawing.Size(45, 126);
            this.trkBrHeight.TabIndex = 24;
            this.trkBrHeight.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trkBrHeight.Value = 1;
            this.trkBrHeight.Scroll += new System.EventHandler(this.trkBrHeight_Scroll);
            // 
            // timer1
            // 
            this.timer1.Interval = 300;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnPattern);
            this.groupBox2.Controls.Add(this.btnPatternRoute);
            this.groupBox2.Location = new System.Drawing.Point(423, 250);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(126, 85);
            this.groupBox2.TabIndex = 62;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Mission3";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnM2Land);
            this.groupBox3.Controls.Add(this.btnTest1);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(423, 10);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(256, 237);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mission2";
            // 
            // btnM2Land
            // 
            this.btnM2Land.Location = new System.Drawing.Point(134, 202);
            this.btnM2Land.Name = "btnM2Land";
            this.btnM2Land.Size = new System.Drawing.Size(115, 27);
            this.btnM2Land.TabIndex = 63;
            this.btnM2Land.Text = "Mission2 Land";
            this.btnM2Land.UseVisualStyleBackColor = true;
            this.btnM2Land.Click += new System.EventHandler(this.btnM2Land_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.trkBrGazAcc);
            this.groupBox4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox4.Location = new System.Drawing.Point(134, 24);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(115, 162);
            this.groupBox4.TabIndex = 62;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "하강 속도 조절";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 12);
            this.label3.TabIndex = 28;
            this.label3.Text = "상";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 12);
            this.label2.TabIndex = 27;
            this.label2.Text = "하";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 12);
            this.label1.TabIndex = 26;
            this.label1.Text = "중";
            // 
            // trkBrGazAcc
            // 
            this.trkBrGazAcc.LargeChange = 1;
            this.trkBrGazAcc.Location = new System.Drawing.Point(37, 13);
            this.trkBrGazAcc.Maximum = 2;
            this.trkBrGazAcc.Name = "trkBrGazAcc";
            this.trkBrGazAcc.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trkBrGazAcc.Size = new System.Drawing.Size(45, 126);
            this.trkBrGazAcc.TabIndex = 24;
            this.trkBrGazAcc.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trkBrGazAcc.Value = 1;
            this.trkBrGazAcc.Scroll += new System.EventHandler(this.trkBrGazAcc_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(690, 370);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.devListBox);
            this.Controls.Add(this.btnGazDown);
            this.Controls.Add(this.btnGazUp);
            this.Controls.Add(this.btnRollDown);
            this.Controls.Add(this.btnRollUp);
            this.Controls.Add(this.btnPitchDown);
            this.Controls.Add(this.btnPitchUp);
            this.Controls.Add(this.btnYawDown);
            this.Controls.Add(this.btnYawUp);
            this.Controls.Add(this.btnEStop);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnInit);
            this.Controls.Add(this.btnLand);
            this.Controls.Add(this.btnTakeOff);
            this.Controls.Add(this.txtProfile);
            this.Controls.Add(this.btnSearch);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HelloDrone";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkBrHeight)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkBrGazAcc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtProfile;
        private System.Windows.Forms.Button btnTakeOff;
        private System.Windows.Forms.Button btnLand;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolSSLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolSSCommand;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button btnEStop;
        private System.Windows.Forms.ToolStripProgressBar toolSPBattery;
        private System.Windows.Forms.Button btnYawUp;
        private System.Windows.Forms.Button btnYawDown;
        private System.Windows.Forms.Button btnPitchUp;
        private System.Windows.Forms.Button btnPitchDown;
        private System.Windows.Forms.Button btnRollDown;
        private System.Windows.Forms.Button btnRollUp;
        private System.Windows.Forms.Button btnGazDown;
        private System.Windows.Forms.Button btnGazUp;
        private System.Windows.Forms.Button btnTest1;
        private System.Windows.Forms.Button btnPatternRoute;
        private System.Windows.Forms.Button btnPattern;
        private System.Windows.Forms.ComboBox devListBox;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.TrackBar trkBrHeight;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar trkBrGazAcc;
        private System.Windows.Forms.Button btnM2Land;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}

