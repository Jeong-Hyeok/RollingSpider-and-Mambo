﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Drawing.Drawing2D;


namespace spider
{
    public partial class Form2 : Form
    {
        public static int clickcount = 0; // 마우스 클릭수 초기값
        int lineLength; // 직선 길이 변수 선언
        double RotateAngle; // 회전 각도 변수 선언
        double RotateSign; // 회전 방향 변수 선언
        public static int[] x = new int[100]; // x좌표 배열 선언
        public static int[] y = new int[100]; // y좌표 배열 선언
        public static int[] lineLengthArray = new int[100]; // 직선 길이 배열 선언
        public static double[] RotateAngleArray = new double[100]; // 회전 각도 배열 선언 
        public static double[] RotateSignArray = new double[100]; // 회전 방향 배열 선언

        public Form2()
        {
            InitializeComponent();
        }
        
        private void Form2_Paint(object sneder, PaintEventArgs e)
        {
            int sz = 50;
            Pen p = new Pen(Color.Gray);
            for (int x = 0; x < this.Width; x += sz)
                e.Graphics.DrawLine(p,x,0,x,this.Height);
            for (int y = 0; y < this.Height; y += sz)
                e.Graphics.DrawLine(p, 0, y, this.Width, y);
        }

        private  void Form2_MouseDown(object sender, MouseEventArgs e) // 마우스 클릭 이동 좌표 표시와 이동 경로 표시
        {     
            int width = 10; //폭
            int offset = width / 2; //옵셋
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red); // 브러쉬 색 선정
            System.Drawing.Graphics formGraphics = this.CreateGraphics(); // 그래픽 만드는 변수 선언
            formGraphics.FillEllipse(myBrush, new Rectangle(e.X - offset, e.Y - offset, width, width)); // 원형 모양으로 마우스가 누른지점 좌표에 표시
            labelLocation.Text = "Location : " + "(" + e.X+ "," + e.Y + ")"; // 좌표 상단에 표시           

            clickcount++; // 마우스 클릭수 증가
           
            x[clickcount - 1] = e.X; // x배열에 x좌표 대입
            y[clickcount - 1] = e.Y; // y배열에 y좌표 대입

            LineMake(); // 선그리기 함수 불러오기
        }

        //변수
        double MySlope1, MySlope2;
        double MyAngle1, MyAngle2;
        double MyAngle3; //Included Angle
        double Mygradient1;
        private void LineMake() // 선 그리기, 선 길이 표시 함수
        {
            if (clickcount > 1) // 클릭 카운터 2 이상일때
            {
                // 직선 그리기
                Graphics g = CreateGraphics(); // 그래픽 만드는 변수로 g 선언
                AdjustableArrowCap bigArrow = new AdjustableArrowCap(5, 5); // 화살표 크기 설정
                Pen pen = new Pen(Color.Cyan, 2); //pen 객체생성및 속성정의(선을 그리기위해 pen이 필요)
                pen.StartCap = LineCap.RoundAnchor; // 화살표 시작점
                pen.CustomEndCap = bigArrow; //화살표 끝점
                Point point1 = new Point(x[clickcount - 2], y[clickcount - 2]); // 첫번째 좌표
                Point point2 = new Point(x[clickcount - 1], y[clickcount - 1]); // 두번째 좌표
                g.DrawLine(pen, point1, point2); //선 그리기

                // 처음 좌표 시작점 표시
                Point textStartPoint = new Point(x[0] - 50, y[0]); // 글자 위치 지정
                Font myFontStart = new Font("맑은고딕", 10, FontStyle.Bold); // 폰트 설정
                Brush greenBrushStart = new SolidBrush(Color.Green); // Font색 설정
                g.DrawString("Start Position", myFontStart, greenBrushStart, textStartPoint); // 문자를 대입                

                // 직선 길이 구함
                int dx = x[clickcount - 1] - x[clickcount - 2]; // x좌표 차이
                int dy = y[clickcount - 1] - y[clickcount - 2]; // y좌표 차이
                lineLength = (int)Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2)); // 두점 사이 길이 계산
                labelLocation.Text = "Location : " + "(" + x[clickcount - 1] + "," + y[clickcount - 1] + ")" + "     LineLength : " + lineLength; // 좌표, 직선길이 상단에 표시
                
                // 직선 길이를 화면에 표시
                Point textLinePoint = new Point(dx/2 + x[clickcount - 2] - 15, dy/2 + y[clickcount - 2] - 10); // 글자 위치 지정
                Font myFontLine = new Font("맑은고딕", 10, FontStyle.Bold); // 폰트 설정
                Brush blackBrush1 = new SolidBrush(Color.Black); // Font색 설정
                g.DrawString(lineLength + "cm", myFontLine, blackBrush1, textLinePoint); // 문자를 대입

                lineLengthArray[clickcount - 2] = lineLength; // 직선길이 배열로 저장 [0]부터 저장시작

                if (clickcount > 2) // 클릭 카운터가 3 이상일떄
                {
                    Point p1 = new Point(x[clickcount - 3], y[clickcount - 3]);
                    Point p2 = new Point(x[clickcount - 2], y[clickcount - 2]);
                    Point p3 = new Point(x[clickcount - 1], y[clickcount - 1]);

                    //각과 기울기
                    if (p1.Y <= p2.Y)
                    {
                        Mygradient1 = (-((double)p1.Y - (double)p2.Y) / ((double)p1.X - (double)p2.X));
                        MySlope1 = Math.Atan2(-(p1.Y - p2.Y), p1.X - p2.X);
                        MyAngle1 = (int)((MySlope1 * 180) / Math.PI);
                    }
                    else if (p1.Y > p2.Y)
                    {
                        Mygradient1 = (-((double)p2.Y - (double)p1.Y) / ((double)p2.X - (double)p1.X));
                        MySlope1 = Math.Atan2(-(p2.Y - p1.Y), p2.X - p1.X);
                        MyAngle1 = (int)((MySlope1 * 180) / Math.PI);
                    }

                    if (p2.Y <= p3.Y)
                    {
                        MySlope2 = Math.Atan2(-(p2.Y - p3.Y), p2.X - p3.X);
                        MyAngle2 = (int)((MySlope2 * 180) / Math.PI);
                    }
                    else if (p2.Y > p3.Y)
                    {
                        MySlope2 = Math.Atan2(-(p3.Y - p2.Y), p3.X - p2.X);
                        MyAngle2 = (int)((MySlope2 * 180) / Math.PI);
                    }

                    if ((p1.Y < p2.Y && p2.Y < p3.Y) || (p1.Y > p2.Y && p2.Y > p3.Y))
                    {
                        MyAngle3 = 180 - Math.Abs(MyAngle1 - MyAngle2);
                    }
                    else
                    {
                        MyAngle3 = Math.Abs(MyAngle1 - MyAngle2);
                    }

                    if (MyAngle1 < 90)
                    {
                        if (p1.X < p2.X)
                        {
                            if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) > 0))
                            {
                                //왼쪽
                                RotateSignArray[clickcount - 2] = -1;
                                RotateAngle = 180 - MyAngle3;
                            }
                            else if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) <= 0))
                            {
                                //오른쪽
                                RotateSignArray[clickcount - 2] = 1;
                                RotateAngle = 180 - MyAngle3;
                            }
                        }
                        else if (p1.X > p2.X)
                        {
                            if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) > 0))
                            {
                                //오른쪽
                                RotateSignArray[clickcount - 2] = 1;
                                RotateAngle = 180 - MyAngle3;
                            }
                            else if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) <= 0))
                            {
                                //왼쪽
                                RotateSignArray[clickcount - 2] = -1;
                                RotateAngle = 180 - MyAngle3;
                            }
                        }
                    }
                    else if (MyAngle1 > 90)
                    {
                        if (p1.X < p2.X)
                        {
                            if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) > 0))
                            {
                                //왼쪽
                                RotateSignArray[clickcount - 2] = -1;
                                RotateAngle = 180 - MyAngle3;
                            }
                            else if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) <= 0))
                            {
                                //오른쪽
                                RotateSignArray[clickcount - 2] = 1;
                                RotateAngle = 180 - MyAngle3;
                            }
                        }
                        else if (p1.X > p2.X)
                        {
                            if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) > 0))
                            {
                                //오른쪽
                                RotateSignArray[clickcount - 2] = 1;
                                RotateAngle = 180 - MyAngle3;
                            }
                            else if ((-(p3.Y - p1.Y) - Mygradient1 * (p3.X - p1.X) <= 0))
                            {
                                //왼쪽
                                RotateSignArray[clickcount - 2] = -1;
                                RotateAngle = 180 - MyAngle3;
                            }
                        }
                    }
                    else if (MyAngle1 == 90)
                    {
                        if (p2.X < p3.X)
                        {
                            RotateSignArray[clickcount - 2] = 1;
                            RotateAngle = 180 - MyAngle3;
                        }
                        else if (p2.X > p3.X)
                        {
                            RotateSignArray[clickcount - 2] = -1;
                            RotateAngle = 180 - MyAngle3;
                        }
                        else if (p2.X == p3.X)
                            RotateAngle = 0;
                    }

                    RotateAngleArray[clickcount - 3] = Math.Round(RotateAngle, 0); // 회전 각도 배열로 저장 [0]부터 저장시작

                    if (RotateSignArray[clickcount - 2] == 1)
                    {
                        labelLocation.Text = "Location : " + "(" + x[clickcount - 1] + "," + y[clickcount - 1] + ")" + "     LineLength : " + lineLength + "     Angle : " 
                            + "오른쪽 " + Math.Round(RotateAngle, 0); // 각도를 이루는 첫번째선 기준으로 세번째점이 위에있으면  오른쪽 회전각도가 나오고, 밑에있으면 왼쪽 회전각도가 나온다.                        
                    }

                    else if (RotateSignArray[clickcount - 2] == -1)
                    {
                        labelLocation.Text = "Location : " + "(" + x[clickcount - 1] + "," + y[clickcount - 1] + ")" + "     LineLength : " + lineLength + "     Angle : " 
                            + "왼쪽 " + Math.Round(RotateAngle, 0); // 각도를 이루는 첫번째선 기준으로 세번째점이 위에있으면  오른쪽 회전각도가 나오고, 밑에있으면 왼쪽 회전각도가 나온다
                    }

                    // 직선 사이 각도를 화면에 표시
                    Point textAnglePoint = new Point(x[clickcount - 2], y[clickcount - 2]); // 글자 위치 지정
                    Font myFontAngle = new Font("맑은고딕", 10, FontStyle.Bold); // 폰트 설정
                    Brush blackBrush = new SolidBrush(Color.Black); // Font색 설정
                    string AngleText = Convert.ToString(Math.Round(MyAngle3, 0)); // int형을 string으로 변형
                    g.DrawString(AngleText + "°", myFontAngle, blackBrush, textAnglePoint); // 문자를 대입        
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e) // 초기화 버튼
        {
            Refresh(); // 그림 전부 초기화
            clickcount = 0; // 마우스 클릭수 초기화
            lineLength = 0; // 직선 길이 변수 초기화
            RotateAngle = 0; // 회전각 초기화
            RotateSign = 0; // 회전신호 초기화
            int[] x = new int[100]; // x좌표 배열 초기화
            int[] y = new int[100]; // y좌표 배열 초기화
            int[] lineLengthArray = new int[100]; // 직선 길이 배열 초기화
            double[] RotateAngleArray = new double[100]; // 회전 각도 배열 초기화
            double[] RotateSignArray = new double[100]; // 회전 방향 배열 초기화
    }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // 마지막 도착지점 표시
            Graphics g = CreateGraphics(); // 그래픽 만드는 변수로 g 선언
            Point textEndPoint = new Point(x[clickcount - 1] - 50, y[clickcount - 1]); // 글자 위치 지정
            Font myFontEnd = new Font("맑은고딕", 10, FontStyle.Bold); // 폰트 설정
            Brush greenBrushEnd = new SolidBrush(Color.Green); // Font색 설정
            g.DrawString("End Position", myFontEnd, greenBrushEnd, textEndPoint); // 문자를 대입            
        }
    }
}