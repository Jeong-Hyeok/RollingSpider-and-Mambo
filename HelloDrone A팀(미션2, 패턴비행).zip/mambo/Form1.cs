﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

using Windows.Devices;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Devices.Enumeration;
using Windows.Storage.Streams;


namespace spider
{
    public partial class Form1 : Form
    {
        #region Form2에서 불러온 변수 선언 값들
        // Form2에서 불러온 값들
        int clickcountForm1 = Form2.clickcount; // 마우스 클릭수
        int[] lineLengthForm1 = Form2.lineLengthArray; // 직선 길이 변수 배열
        double[] RotateAngleForm1 = Form2.RotateAngleArray; // 회전각도 변수 배열
        double[] RotateSignForm1 = Form2.RotateSignArray; // 회전방향 변수 배열        
        int[] x2 = Form2.x; // x좌표 배열 선언
        int[] y2 = Form2.y; // y좌표 배열 선언
        #endregion
        #region 블루투스 연결, 초기화, 기타 통신 설정, 베터리 정보

        int ackSeqNo = -1;
        int cmdSeqNo = -1;
        int cmdXSeqNo = -1;
        int mTime;
        byte mBattery, mStatus;
        sbyte roll;
        sbyte pitch;
        sbyte yaw;
        sbyte gaz;

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void Search_Click(object sender, EventArgs e)
        {
            txtProfile.Text = "Searching BLE Devices...";
            devListBox.Items.Clear();
            var devL = await DeviceInformation.FindAllAsync(BluetoothLEDevice.GetDeviceSelector());
            foreach (var di in devL)
            {
                var dev = await BluetoothLEDevice.FromIdAsync(di.Id);
                foreach (var svc in dev.GattServices)
                    if (dev.Name.Contains("Mambo"))
                        devListBox.Items.Add("[" + di.Name + "] :" + svc.Uuid.ToString());
            }
            if (devListBox.Items.Count >= 1)
                devListBox.Text = devListBox.Items[0].ToString();
            else
                devListBox.Text = "No device found.";
        }
        private void xtest()
        {
            byte[] cmd = new byte[] { 2, 1, 0, 4, 2, 0 };
            var ss = Encoding.UTF8.GetBytes(DateTime.Now.ToString("Thhmmsss+0900"));
            byte[] buf = new byte[cmd.Length + ss.Length];
            cmd.CopyTo(buf, 0);
            ss.CopyTo(buf, cmd.Length);
            toolSSCommand.Text = BitConverter.ToString(buf);
        }

        private async void devListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string item = devListBox.SelectedItem.ToString();
            string uuid = item.Substring(item.IndexOf(":") + 1);

            // Service UUID Search
            var devL = await DeviceInformation.FindAllAsync(
                GattDeviceService.GetDeviceSelectorFromUuid(new Guid(uuid)));

            //Connect to the service  
            var svc = await GattDeviceService.FromIdAsync(devL[0].Id);

            //Obtain the characteristic we want to interact with  
            var chrL = svc.GetAllCharacteristics();

            foreach (var chr in chrL)
            {
                txtProfile.AppendText(">>" + chr.Uuid.ToString() + "...");
                txtProfile.AppendText(chr.CharacteristicProperties.ToString() + "\r\n");
                if ((Convert.ToUInt16(chr.CharacteristicProperties) &
                    Convert.ToUInt16(GattCharacteristicProperties.Read)) > 0)
                {
                    var result = await chr.ReadValueAsync();
                    var data = BitConverter.ToString(result.Value.ToArray());
                    txtProfile.AppendText("...[" + data + "]\r\n");
                }
            }
            svc.Dispose();
        }

        private void Chr_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            throw new NotImplementedException();
        }

        List<string> SvcL = new List<string> { };
        private GattCharacteristic chrCmdfa0b = null;   //command
        private GattCharacteristic chrAckfa1e = null;   //ack
        private GattCharacteristic chrCmdfa0c = null;   //Emergency

        private async void btnInit_Click(object sender, EventArgs e)
        {
            txtProfile.Clear();

            //특정 디바이스 서비스ID를 추출
            string item = devListBox.SelectedItem.ToString();
            string name = item.Substring(0, item.IndexOf(":"));
            foreach (var id in devListBox.Items)
            {
                item = id.ToString();
                if (item.Contains(name))
                {
                    //txtProfile.AppendText(item.Substring(item.IndexOf(":")+1));
                    SvcL.Add(item.Substring(item.IndexOf(":") + 1));
                }
            }
            txtProfile.Text = "Notifying...\r\n";
            foreach (var uuid in SvcL)
            {
                // Service UUID Search
                var devL = await DeviceInformation.FindAllAsync(
                    GattDeviceService.GetDeviceSelectorFromUuid(new Guid(uuid)));

                //Connect to the service  
                var svc = await GattDeviceService.FromIdAsync(devL[0].Id);

                //Obtain the characteristic we want to interact with  
                var chrL = svc.GetAllCharacteristics();

                foreach (var chr in chrL)
                {

                    var id = chr.Uuid.ToString();
                    if (id.Contains("fa0b"))
                        chrCmdfa0b = chr;//command 보내기

                    if (id.Contains("fa0c"))
                        chrCmdfa0c = chr;//Emergency 보내기

                    if (id.Contains("fa1e"))
                        chrAckfa1e = chr;//Ack 보내기

                    if (chr.CharacteristicProperties.HasFlag(GattCharacteristicProperties.Notify))
                    {
                        if (id.Contains("fb0e"))
                            chr.ValueChanged += onChrfb0e_ValueChanged;
                        else if (id.Contains("fb0f"))
                            chr.ValueChanged += onChrfb0f_ValueChanged;
                        else
                            chr.ValueChanged += onChrfxxx_ValueChanged;

                        var status = await chr.WriteClientCharacteristicConfigurationDescriptorAsync(
                                        GattClientCharacteristicConfigurationDescriptorValue.Notify);

                        txtProfile.AppendText(">" + chr.Uuid.ToString() + "...");
                        if (status == GattCommunicationStatus.Unreachable)
                        {
                            txtProfile.AppendText("Device is unreachable!\r\n");
                            return;
                        }
                        else
                        {
                            txtProfile.AppendText("Done \r\n");
                        }
                    }
                }
            }
            txtProfile.AppendText("\r\nConfiguring...");
            cmdAllSettings();
            cmdAllStates();
            cmdCurrentDate();
            cmdCurrentTime();
            mTime = DateTime.Now.Millisecond;
            txtProfile.AppendText("Done \r\n");
            btnInit.Text = "Notify";
        }

        public string debugMessage = "";

        private void onChrfb0f_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            var data = new byte[args.CharacteristicValue.Length];

            data = args.CharacteristicValue.ToArray();
            if (data.Length == 7 && data[2] == 0 && data[3] == 5 && data[4] == 1 && data[5] == 0)
            {   //Data(2)-seqno(x)-Common(0)-CommonState(5)-BatteryStateChanged(1,0)-BatteryPercentagy(x)
                mBattery = data[6];
                toolSPBattery.Value = mBattery;
                if (mBattery < 20)
                {
                    btnEStop.BackColor = Color.Red;
                }
                txtProfile.AppendText(mBattery.ToString() + "% \r\n");
            }
            txtProfile.AppendText("[B" + args.CharacteristicValue.Length + "]" + BitConverter.ToString(data) + "\r\n");
        }

        private void sendAck(byte fn)
        {
            byte[] cmd = new byte[] { 1, 1, 0 };  //Ack(1)-sn-fn

            cmd[1] = (byte)(++ackSeqNo & 0xff);
            cmd[2] = fn;
            sendCommand(chrAckfa1e, cmd, GattWriteOption.WriteWithoutResponse);
            txtProfile.AppendText("@");
        }

        private void onChrfb0e_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            string[] state = { "Landed", "Taking off", "Hovering", "Flying", "Landing", "Emergency", "rolling", "Initializing" };
            var data = new byte[args.CharacteristicValue.Length];
            string ack = "";

            data = args.CharacteristicValue.ToArray();

            if (data[0] == 4)
                sendAck(data[1]);

            if (data.Length == 10 && data[2] == 2 && data[3] == 3 && data[4] == 1 && data[5] == 0)
            {   //Data(2)-seqno(x)-MiniDrone(2)-PilotingState(3)-FlightStateChanged(1,0)-state(x)
                mStatus = data[6];
                txtProfile.AppendText(state[mStatus] + "\r\n");
            }
            txtProfile.AppendText("[S" + args.CharacteristicValue.Length + "]" + BitConverter.ToString(data) + ack + "\r\n");
        }

        private void onChrfxxx_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            var data = new byte[args.CharacteristicValue.Length];

            data = args.CharacteristicValue.ToArray();

            txtProfile.AppendText("[X" + args.CharacteristicValue.Length + "]" + BitConverter.ToString(data) + "\r\n");
        }

        private async void sendCommand(GattCharacteristic chr, byte[] cmd, GattWriteOption ack)
        {
            var status = await chr.WriteValueAsync(cmd.AsBuffer(), ack);
            if (status == GattCommunicationStatus.Unreachable)
                txtProfile.AppendText("[Device is unreachable!]");

        }
        #endregion
        #region cmd 명령
        private void cmdAllSettings()
        {
            byte[] cmd = new byte[] { 2, 1, 0, 2, 0, 0 };  //Data(2)-sn-common(0)-Settings(2)-AllSettings(00)
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            txtProfile.AppendText("cmdAllSettings...");
            txtProfile.AppendText(BitConverter.ToString(cmd));
            txtProfile.AppendText("Done \r\n");
        }

        private void cmdAllStates()
        {
            byte[] cmd = new byte[] { 2, 1, 0, 4, 0, 0 };  //Data(2)-sn-common(0)-Common(4)-AllStates(00)
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            txtProfile.AppendText("cmdAllStates...");
            txtProfile.AppendText(BitConverter.ToString(cmd));
            sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            txtProfile.AppendText("Done \r\n");
        }

        private void cmdCurrentTime()
        {
            byte[] cmd = new byte[] { 2, 1, 0, 4, 2, 0 }; //Data(2)-sn-common(0)-Common(4)-Time(02)
            var ss = Encoding.UTF8.GetBytes(DateTime.Now.ToString("Thhmmsss+0900"));
            byte[] buf = new byte[cmd.Length + ss.Length];

            cmd.CopyTo(buf, 0);
            ss.CopyTo(buf, cmd.Length);
            toolSSCommand.Text = BitConverter.ToString(buf);
            toolSSCommand.Text = BitConverter.ToString(buf);
            buf[1] = (byte)(++cmdSeqNo & 0xff);
            sendCommand(chrCmdfa0b, buf, GattWriteOption.WriteWithoutResponse);
        }

        private void cmdCurrentDate()
        {
            byte[] cmd = new byte[] { 2, 1, 0, 4, 1, 0 }; //Data(2)-sn-common(0)-Common(4)-Date(01)
            var ss = Encoding.UTF8.GetBytes(DateTime.Now.ToString("yyyy-MM-dd"));
            byte[] buf = new byte[cmd.Length + ss.Length];

            cmd.CopyTo(buf, 0);
            ss.CopyTo(buf, cmd.Length);
            toolSSCommand.Text = BitConverter.ToString(buf);
            toolSSCommand.Text = BitConverter.ToString(buf);
            buf[1] = (byte)(++cmdSeqNo & 0xff);
            sendCommand(chrCmdfa0b, buf, GattWriteOption.WriteWithoutResponse);
        }

        private void cmdPCMDTime(byte flg, sbyte roll, sbyte pitch, sbyte yaw, sbyte gaz)
        {
            byte[] cmd = new byte[] { 2, 1, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            byte[] ss = BitConverter.GetBytes(DateTime.Now.Millisecond - mTime);
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            cmd[6] = flg;   //Boolean flag to activate roll/pitch movement
            cmd[7] = (byte)roll;
            cmd[8] = (byte)pitch;
            cmd[9] = (byte)yaw;
            cmd[10] = (byte)gaz;
            ss.CopyTo(cmd, 11);
            toolSSCommand.Text = BitConverter.ToString(cmd);
            sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
        }

        private void cmdFlatTrim()
        {
            byte[] cmd = new byte[] { 2, 0, 2, 0, 0, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-FlatTrim(00)
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            toolSSCommand.Text = BitConverter.ToString(cmd);
            debugMessage += "<" + toolSSCommand.Text + ">";
            sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
        }

        private void txtProfile_DoubleClick(object sender, EventArgs e)
        {
            txtProfile.Text = "";
        }

        private void txtProfile_Click(object sender, EventArgs e)
        {
            txtProfile.AppendText(debugMessage);
            debugMessage = "";
        }
        #endregion
        #region yaw, pitch, roll, gaz
        private void btnYawUp_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 0, 0, 100, 0); //10도는+6 ,30도는 +17.5 회전가능, 지금은 5도 회전가능
        }

        private void btnYawDown_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 0, 0, -100, 0); //-10도는-6 ,-30도는 -17.5 회전가능, 지금은 -5도 회전가능
        }

        private void btnPitchUp_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 0, 100, 0, 0); // 피치 100 = 60cm 정도
        }

        private void btnPitchDown_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 0, -100, 0, 0);
        }

        private void btnRollUp_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 100, 0, 0, 0);
        }

        private void btnRollDown_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, -100, 0, 0, 0);
        }

        private void btnGazUp_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 0, 0, 0, 100);
        }

        private void btnGazDown_Click(object sender, EventArgs e)
        {
            cmdPCMDTime(1, 0, 0, 0, -100);
        }
        #endregion
        #region 이륙, 비상착륙, 착륙
        private void btnTakeOff_Click(object sender, EventArgs e)
        {
            byte[] cmd = new byte[] { 2, 0, 2, 0, 1, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-TakeOff(01)
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            toolSSCommand.Text = BitConverter.ToString(cmd);
            debugMessage += "<" + toolSSCommand.Text + ">";
            sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
        }

        private void btnEStop_Click(object sender, EventArgs e)
        {
            byte[] cmd = new byte[] { 4, 0, 2, 0, 4, 0 };   //DataWithAck(4)-sn-minidrone(2)-Piloting(0)-Emergency(04)
            cmd[1] = (byte)(++cmdXSeqNo & 0xff);
            toolSSCommand.Text = BitConverter.ToString(cmd);
            sendCommand(chrCmdfa0c, cmd, GattWriteOption.WriteWithoutResponse);
        }

        private void btnLand_Click(object sender, EventArgs e)
        {
            byte[] cmd = new byte[] { 2, 0, 2, 0, 3, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-TakeOff(03)
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            toolSSCommand.Text = BitConverter.ToString(cmd);
            debugMessage += "<" + toolSSCommand.Text + ">";
            sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
        }
        #endregion 
        #region Mission2

        string MyCmd = "";
        int MyIndex = 0;
        int MyDelay = 0;
        int MyHeight;

        private void trkBrHeight_Scroll(object sender, EventArgs e) // 높이 조절 바
        {
            if (trkBrHeight.Value == 0)
            {
                MyCmd = "HD";
            }
            else if (trkBrHeight.Value == 1)
            {
                MyCmd = "";
            }
            else if (trkBrHeight.Value == 2)
            {
                MyCmd = "HU";
            }
        }

        private void timer1_Tick(object sender, EventArgs e) // 이륙 높이 조절
        {
            var cmd = MyCmd.ToCharArray();
            if (MyDelay > 0)
            {
                MyDelay--;
                timer1.Enabled = true;
                return;
            }

            if (MyIndex >= MyCmd.Length)
            {
                timer1.Enabled = false;
                MyIndex = 0;
                return;
            }

            switch (cmd[MyIndex++])
            {
                case 'H':
                    MyDelay = 5;
                    break;

                case 'U':
                    cmdPCMDTime(1, 0, 0, 0, 55); // 60cm
                    break;

                case 'D':
                    cmdPCMDTime(1, 0, 0, 0, -30); // 60cm
                    break;
            }
        }

        int GazAcc;
        private void trkBrGazAcc_Scroll(object sender, EventArgs e) // Gaz 가속 설정
        {
            if (trkBrGazAcc.Value == 0)
            {
                GazAcc = 0;
                byte[] cmd = new byte[] { 2, 0, 2, 1, 0, 0, 0, 0, 0, 1 };   // gaz 속도 조절 1~100 사이
                cmd[1] = (byte)(++cmdSeqNo & 0xff);
                sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            }
            else if (trkBrGazAcc.Value == 1)
            {
                GazAcc = 1;
                byte[] cmd = new byte[] { 2, 0, 2, 1, 0, 0, 0, 0, 0, 50 };   // gaz 속도 조절 1~100 사이
                cmd[1] = (byte)(++cmdSeqNo & 0xff);
                sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            }
            else if (trkBrGazAcc.Value == 2)
            {
                GazAcc = 2;
                byte[] cmd = new byte[] { 2, 0, 2, 1, 0, 0, 0, 0, 0, 100 };   // gaz 속도 조절 1~100 사이
                cmd[1] = (byte)(++cmdSeqNo & 0xff);
                sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            }
        }          

        private void btnTest1_Click(object sender, EventArgs e) // 이륙 -> 호버링 미션
        {
            byte[] cmd1 = new byte[] { 2, 0, 2, 0, 1, 0 };   // 이륙
            cmd1[1] = (byte)(++cmdSeqNo & 0xff);
            toolSSCommand.Text = BitConverter.ToString(cmd1);
            debugMessage += "<" + toolSSCommand.Text + ">";
            sendCommand(chrCmdfa0b, cmd1, GattWriteOption.WriteWithoutResponse);
            Delay(1000);

            timer1.Enabled = true;
            Delay(2000);
        }

        private void btnM2Land_Click(object sender, EventArgs e) // 착륙 명령
        {
            if (GazAcc == 0)
            {
                cmdPCMDTime(1, 0, 0, 0, -100);
                Delay(300);
                cmdPCMDTime(1, 0, 0, 0, -100);
                Delay(300);
                cmdPCMDTime(1, 0, 0, 0, -100);
                Delay(300);

                byte[] cmd = new byte[] { 2, 0, 2, 0, 3, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-TakeOff(03)
                cmd[1] = (byte)(++cmdSeqNo & 0xff);
                sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            }
            if (GazAcc == 1)
            {
                cmdPCMDTime(1, 0, 0, 0, -100);
                Delay(500);
                cmdPCMDTime(1, 0, 0, 0, -100);
                Delay(500);

                byte[] cmd = new byte[] { 2, 0, 2, 0, 3, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-TakeOff(03)
                cmd[1] = (byte)(++cmdSeqNo & 0xff);
                sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            }
            if (GazAcc == 2)
            {
                cmdPCMDTime(1, 0, 0, 0, -100);
                Delay(1000);

                byte[] cmd = new byte[] { 2, 0, 2, 0, 3, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-TakeOff(03)
                cmd[1] = (byte)(++cmdSeqNo & 0xff);
                sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            }
        }
        #endregion   
        #region Mission3

        private void btnPatternRoute_Click(object sender, EventArgs e) // 패턴 비행 경로 설정
        {
            Form2 PatternFlight = new Form2();
            PatternFlight.Show();
        }        

        private void btnPattern_Click(object sender, EventArgs e) // 패턴 비행
        {
            int num = Form2.clickcount - 2; // 마우스 클릭수 보다 1개 많게해서 for문 시도            

            byte[] cmd = new byte[] { 2, 0, 2, 0, 1, 0 };   //Data(2)-sn-minidrone(2)-Piloting(0)-TakeOff(01)
            cmd[1] = (byte)(++cmdSeqNo & 0xff);
            sendCommand(chrCmdfa0b, cmd, GattWriteOption.WriteWithoutResponse);
            Delay(1000);

            timer1.Enabled = true;
            Delay(3000);

            for (clickcountForm1 = 0; clickcountForm1 < num; clickcountForm1++) // 직진, 회전 반복
            {
                dronePitch(lineLengthForm1[clickcountForm1]); // 직진
                Delay(2000);

                droneRotate(RotateAngleForm1[clickcountForm1], RotateSignForm1[clickcountForm1 + 1]); // 회전
                Delay(1000); //3000

                if (Form2.clickcount == clickcountForm1 + 3) // 마지막 좌표점으로 이동
                {
                    dronePitch(lineLengthForm1[clickcountForm1 + 1]); // 직전
                    cmdPCMDTime(1, 0, 0, 0, 0);
                    Delay(2000); //1000
                }
            }

            byte[] cmd1 = new byte[] { 2, 0, 2, 0, 3, 0 }; // 착륙
            cmd1[1] = (byte)(++cmdSeqNo & 0xff);
            sendCommand(chrCmdfa0b, cmd1, GattWriteOption.WriteWithoutResponse);
        }

        private void droneRotate(double rotate, double angle) // 드론 회전 함수  
        {
            double rotateDrone;

            // 100일때 60도 회전, 50일때 30도 회전, 5/3일때 1도 회전
            if (angle == -1) // 좌 회전
            {
                if(rotate >= 0 && rotate <= 60)
                {
                    rotateDrone = -1 * rotate * (5 / 3);
                    cmdPCMDTime(1, 0, 0, (sbyte)rotateDrone, 0);
                    Delay(500);

                }
                if(rotate > 60 && rotate <= 120)
                {
                    cmdPCMDTime(1, 0, 0, -100, 0); // 60도 회전
                    Delay(500);
                    rotate = rotate - 60;
                    rotateDrone = -1 * rotate * (5 / 3);
                    cmdPCMDTime(1, 0, 0, (sbyte)rotateDrone, 0); // 60~120 사이 남은 각도 더 회전
                    Delay(500);

                }
                if(rotate > 120 && rotate <= 180)
                {
                    cmdPCMDTime(1, 0, 0, -100, 0); // 60도 회전
                    Delay(500);
                    cmdPCMDTime(1, 0, 0, -100, 0); // 60도 회전
                    Delay(500);
                    rotate = rotate - 120;
                    rotateDrone = -1 * rotate * (5 / 3);
                    cmdPCMDTime(1, 0, 0, (sbyte)rotateDrone, 0); // 120~180 사이 남은 각도 더 회전
                    Delay(500);
                }
            }
            else // 우 회전
            {
                if (rotate >= 0 && rotate <= 60)
                {
                    rotateDrone = rotate * (5 / 3);
                    cmdPCMDTime(1, 0, 0, (sbyte)rotateDrone, 0);
                    Delay(500);

                }
                if (rotate > 60 && rotate <= 120)
                {
                    cmdPCMDTime(1, 0, 0, 100, 0); // 60도 회전
                    Delay(500);
                    rotate = rotate - 60;
                    rotateDrone = rotate * (5 / 3);
                    cmdPCMDTime(1, 0, 0, (sbyte)rotateDrone, 0); // 60~120 사이 남은 각도 더 회전
                    Delay(500);

                }
                if (rotate > 120 && rotate <= 180)
                {
                    cmdPCMDTime(1, 0, 0, 100, 0); // 60도 회전
                    Delay(500);
                    cmdPCMDTime(1, 0, 0, 100, 0); // 60도 회전
                    Delay(500);
                    rotate = rotate - 120;
                    rotateDrone = rotate * (5 / 3);
                    cmdPCMDTime(1, 0, 0, (sbyte)rotateDrone, 0); // 120~180 사이 남은 각도 더 회전
                    Delay(500);
                }
            }
        }

        private void dronePitch(int line) // 드론 직진 함수
        {
            double go;
            if (line < 60) // 0cm ~ 60cm
            {
                cmdPCMDTime(1, 0, 80, 0, 0);
                Delay(500);
            }
            else if (line == 60) // 0cm ~ 60cm
            {
                go = (line * (5 / 3));
                cmdPCMDTime(1, 0, (sbyte)go, 0, 0);
                Delay(500);
            }
            else if (line > 60 && line <= 120) // 60cm ~ 120cm
            {
                cmdPCMDTime(1, 0, 100, 0, 0); // 60cm 전진
                Delay(500);

                line = line - 60;
                go = (line * (5 / 3));
                cmdPCMDTime(1, 0, (sbyte)go, 0, 0); // 60cm ~ 120cm 남은 거리 전진
                Delay(500);
            }

            else if (line > 120 && line <= 180) // 120cm ~ 180cm
            {
                cmdPCMDTime(1, 0, 100, 0, 0); // 60cm 전진
                Delay(500);
                cmdPCMDTime(1, 0, 100, 0, 0); // 60cm 전진
                Delay(500);

                line = line - 120;
                go = (line * (5 / 3));
                cmdPCMDTime(1, 0, (sbyte)go, 0, 0); // 120cm ~ 180cm 남은 거리 전진
                Delay(500);
            }

            else if (line > 180 && line <= 240) // 180cm ~ 240cm
            {
                cmdPCMDTime(1, 0, 100, 0, 0); // 60cm 전진
                Delay(500);
                cmdPCMDTime(1, 0, 100, 0, 0); // 60cm 전진
                Delay(500);
                cmdPCMDTime(1, 0, 100, 0, 0); // 60cm 전진
                Delay(500);

                line = line - 180;
                go = (line * (5 / 3));
                cmdPCMDTime(1, 0, (sbyte)go, 0, 0); // 180cm ~ 240cm 남은 거리 전진
                Delay(500);
            }           
        }        
        #endregion
        #region 딜레이 함수
        //Delay 함수(form 멈춤 현상 없음)
        private static DateTime Delay(int MS)
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);
            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }
            return DateTime.Now;
        }
        #endregion       
    }
}



// 블루투스 연결 오류시 블루투스 4.5.1로 변경할것
